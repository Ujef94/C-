﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagement.Models.Customer
{
    public class CustomerMap
    {
        public CustomerMap(EntityTypeBuilder<CustomerEntity>entityBuilder)
        {
            entityBuilder.HasKey(t => t.Id);
            entityBuilder.Property(t => t.FirstName);
            entityBuilder.Property(t => t.LastName);
            entityBuilder.Property(t => t.Email);
            entityBuilder.Property(t => t.MobileNo);
        }
    }
}
