﻿namespace CustomerManagement.Models.Base
{
    public class Inet64
    {
    }
}